library(testthat)
library(RMSTpowerBoostApp)

test_check("RMSTpowerBoostApp")
